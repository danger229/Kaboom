move the magic folder to C:\Program Files

to have this run at start up, create a shortcut to dist\SplooshKaboom.jar and put that into the startup folder